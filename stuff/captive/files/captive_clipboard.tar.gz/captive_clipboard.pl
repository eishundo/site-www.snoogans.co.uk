#!/usr/bin/perl -wT

# $Id: captive_clipboard.pl,v 1.1.1.1 2005/08/27 00:11:07 chris Exp $

####
# Clipboard decoder for Captive game by Anthony Crowther (Mindscape)
# This program decodes bar clipboards only.
#
# Copyright (c) 1993-2002 Laurent de Soras (laurent@ohmforce.com)
# Copyright (c) 2005 Chris Pile (cpile@snoogans.co.uk)
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
# or look at http://www.gnu.org/licenses/gpl.txt
####

use strict;

####

my($mission, $level, $code);

print "Enter Mission (1 = first one, max = 6000)\n";
while( ($mission = <STDIN>) !~ /\d+/ || ($mission > 6000) ) {
    print "Must be a valid number between 1 and 6000\n";
}

print "Enter Level (0 = first one, max = 10)\n";
while( ($level = <STDIN>) !~ /\d+/ || ($level > 10) ) {
    print "Must be a valid number between 0 and 10\n";
}

print "Enter Code\n";
while( ($code = <STDIN>) !~ /\d+/) {
    print "Must be a valid number\n";
}

print "\n";

chomp($mission, $level, $code);

my $val = &decode_16($mission, $level, $code);
&display_16($code, $val);

####

sub decode_16 {
    my($mission, $level, $code) = @_;

    my $d = 48771 - ($mission * 11 + $level) * 16679;
    my $b = $d - $code;
    my $val = $b / 295;

    while( ($b % 295) != 0 || $code != (($d - 16679 * $val) & 0xFFFF)) {
        $b += 16384;
        $val = $b / 295;
    }

    return($val);
}

sub display_16 {
    my($code, $val) = @_;

    my @col_list = qw{1 3 1 1 3 3 1 3 0 2 3 4 0 1 2 4};
    my @row_list = qw{0 0 1 2 2 3 4 4 1 1 1 1 3 3 3 3};
    my @screen_0;

    for(my $bar = 0;$bar < 16;++$bar) {
        if( ($val & (1 << $bar)) != 0 ) {
          my $col = $col_list[$bar];
          my $row = $row_list[$bar];
          my $bar_char = $bar < 8 ? "-" : "|";
          $screen_0[$row][$col] = $bar_char;
        }
    }
    for(my $r = 0;$r < 5;++$r) {
        for(my $c = 0;$c < 5;++$c) {
            if($screen_0[$r][$c]) {
                print $screen_0[$r][$c];
            }
            else {
                print ".";
            }
        }
        print "\n";
    }
}

1;

__END__
