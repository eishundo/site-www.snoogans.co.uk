/*

Clipboard decoder for Captive game by Anthony Crowther (Mindscape)
This program decodes bar clipboards only.

Copyright (c) 1993-2002 Laurent de Soras (laurent@ohmforce.com)

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
or look at http://www.gnu.org/licenses/gpl.txt

*/



#include    <stdio.h>
#include    <string.h>



long    decode_16 (long code, int mission, int planet);
void    display_16 (long code, long val);



int main (int argc, char *argv [])
{
    int             mission ;   /* Starting from 1 */
    int             planet ;        /* Starting from 0 */
    long                code;
    long                val;

    printf ("%s\n", "Mission (1 = first one) :");
    scanf ("%d", &mission);

    printf ("%s\n", "Planet (0 = first one) :");
    scanf ("%d", &planet);

    printf ("%s\n", "Code :");
    scanf ("%ld", &code);

    val = decode_16 (code, mission, planet);
    printf ("%ld\n", val);
    display_16 (code, val);

    printf ("Press <Return> to exit...\n");
    fflush (stdin);
    getchar ();

    return (0);
}



long    decode_16 (long code, int mission, int planet)
{
    long            d = 48771L - (mission * 11 + planet) * 16679L;
    long            b = d - code;
    long            val = b / 295;

    while (   (b % 295) != 0
           || code != ((d - 16679 * val) & 0xFFFF))
    {
        b += 16384;
        val = b / 295;
    }

    return (val);
}



void    display_16 (long code, long val)
{
    char                screen_0 [6] [6+1];
    static char     col_list [16] = { 1, 3, 1, 1, 3, 3, 1, 3, 0, 2, 3, 4, 0, 1, 2, 4 };
    static char     row_list [16] = { 0, 0, 1, 2, 2, 3, 4, 4, 1, 1, 1, 1, 3, 3, 3, 3 };
    int             bar;
    int             row;
    int             disp_row;

    /* Display initialization */
    memset (screen_0, ' ', sizeof (screen_0));
    for (row = 0; row < 6; ++row)
    {
        screen_0 [row] [6] = '\0';
    }

    /* Prepare screen matrix */
    for (bar = 0; bar < 16; ++bar)
    {
        if ((val & (1L << bar)) != 0)
        {
            int             col = col_list [bar];
            int             row = row_list [bar];
            char                bar_char = (char) ((bar < 8) ? ('-') : ('|'));
            screen_0 [row] [col] = bar_char;
        }
    }

    printf ("%ld\n", code);
    for (disp_row = 0; disp_row < 6; ++disp_row)
    {
        printf ("%s\n", screen_0 [disp_row]);
    }
}

